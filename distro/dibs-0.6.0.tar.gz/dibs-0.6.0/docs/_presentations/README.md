# Presentations about DIBS

This directory contains slides from various presentations given about DIBS.
