# General information

This section provides some general and historical information about DIBS.

```{toctree}
---
maxdepth: 2
---
faqs.md
history.md
references.md
```
