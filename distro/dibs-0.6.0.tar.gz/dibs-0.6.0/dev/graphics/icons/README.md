# Icon sources for DIBS

The [vector artwork](https://thenounproject.com/term/book-waiting/1531542/) of a book with a clock on it, used as the icon for this project, was created by [Royyan Wijaya](https://thenounproject.com/roywj/) from the Noun Project.  It is licensed under the Creative Commons [CC-BY 3.0](https://creativecommons.org/licenses/by/3.0/) license. I edited the logo in [Boxy SVG](https://boxy-svg.com), a native SVG editor for macOS to change the icon color to the orange used by Caltech in their logo.

The [vector artwork](https://thenounproject.com/term/book/2349054/) of a closed book, used in place of missing cover thumbnails, was created by [Scott Desmond](https://thenounproject.com/thezyna/) from the Noun Project.  It is licensed under the Creative Commons [CC-BY 3.0](https://creativecommons.org/licenses/by/3.0/) license.

The [vector artwork](https://thenounproject.com/term/megaphone/505098/) of a megaphone was created by [SlideGenius](https://thenounproject.com/slidegenius/) from the Noun Project.  It is licensed under the Creative Commons [CC-BY 3.0](https://creativecommons.org/licenses/by/3.0/) license.

