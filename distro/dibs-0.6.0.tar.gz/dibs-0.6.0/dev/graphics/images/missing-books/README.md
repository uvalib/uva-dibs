Missing book image
==================

<p xmlns:cc="http://creativecommons.org/ns#" xmlns:dct="http://purl.org/dc/terms/">
The photo of missing books in Caltech's Sherman Fairchild Library, used on the DIBS 404 page, was taken by <a href="https://www.behance.net/InkSketch">Rebecca Minarez</a>, in January, 2021. <a property="dct:title" rel="cc:attributionURL" href="https://github.com/caltechlibrary/dibs/tree/develop/dev/images/missing-books">IMG_1001.JPG</a>
 by <a rel="cc:attributionURL dct:creator" property="cc:attributionName" href="https://www.behance.net/InkSketch">Rebecca R. Minjarez</a>
 is licensed under <a href="http://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">
CC BY-NC-SA 4.0</a>.
</p>
<p align="center">
<a href="http://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">
<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1">
<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1">
<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/nc.svg?ref=chooser-v1">
<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/sa.svg?ref=chooser-v1">
</a>
</p>
