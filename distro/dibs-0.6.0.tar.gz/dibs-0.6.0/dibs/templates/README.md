Conventions for DIBS templates
==============================

Certain conventions are important to follow consistently in these templates, so that our server code functions properly.

* When passing a barcode to or from a web page or form, always call the variable `barcode`.
